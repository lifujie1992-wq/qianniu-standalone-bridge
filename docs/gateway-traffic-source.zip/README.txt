会话网关流量优化源码补丁

替换 PddBridgeAgent 源码目录中的 run_frontend_service.py，然后由 Windows 主机沿用原项目构建流程打包。不要把这个文件替换进千牛 standalone_bridge.py 项目。
本补丁需要服务端已支持 ETag/304；旧服务端没有 ETag 时会继续正常下载，gzip 未启用时正常读明文。
变化：协商 gzip；会话列表和 bootstrap 条件请求；缓存按 URL/客户端身份隔离、上限64项；账号切换丢弃旧异步响应。
刷新频率、消息发布、发送 POST 保持原逻辑；没有给真实客户补发消息。回滚：换回原 run_frontend_service.py 并重新打包旧客户端。
测试见 test_gateway_traffic.py、gateway-manifest.json、后续复盘报告。
